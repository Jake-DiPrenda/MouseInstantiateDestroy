using UnityEngine;

public class Destroy : MonoBehaviour
{
    void OnMouseOver()
    {
        if (Input.GetMouseButtonDown(1))
        {
            Debug.Log("click detected");
            DestroyCube();
        }
    }

    void DestroyCube()
    {
        Destroy(gameObject);
    }

}
