using NUnit.Framework;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    private bool isFacingRight = true;
    public float moveSpeed;
    public float jumpForce;
    public bool isGrounded;
    public GameObject Player;
    public float isMoving;
    public Rigidbody2D my_rb;
    public bool isWallSliding;
    public float wallSlidingSpeed;
    public bool isWallJumping;
    public float wallJumpingDirection;
    public float wallJumpingTime;
    public float wallJumpingCounter;
    public float wallJumpingDuration;
    private Vector2 wallJumpingPower = new Vector2(8f, 16f);

    [SerializeField] private Transform wallCheck;
    [SerializeField] private LayerMask wallLayer;


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Debug.Log("Oh, Hello. This is the GreenBallScript's Start ;p");
    }

    void Update()
    {
        isMoving = Input.GetAxisRaw("Horizontal");
        wallSlide();
        WallJump();
        if (!isWallJumping)
        {
            Flip();
        }
    }
    // Update is called once per frame
    void FixedUpdate()
    {
        
        if (Input.GetKey(KeyCode.RightArrow))
        {
            Debug.Log("The Right key is pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Debug.Log("The Left key is pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space)) && isGrounded)
        {
            Debug.Log("The Up key is pressed.");
            Jump();
        }

        
    }

    void Jump()
    {
        my_rb.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
        isGrounded = false;
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            isGrounded = true;
        }
    }

    private bool isWalled()
    {
        return Physics2D.OverlapCircle(wallCheck.position, 0.2f, wallLayer);
    }

    private void wallSlide()
    {
        if (isWalled() && !isGrounded && isMoving != 0f)
        {
            isWallSliding = true;
            my_rb.velocity = new Vector2(my_rb.velocity.x, Mathf.Clamp(my_rb.velocity.y, -wallSlidingSpeed, float.MaxValue));
        }
        else 
        {
            isWallSliding = false;
        }
    }
    private void WallJump()
    {
        if (isWallSliding)
        {
            isWallJumping = false;
            wallJumpingDirection = -transform.localScale.x;
            wallJumpingCounter = wallJumpingTime;
            CancelInvoke(nameof(StopWallJumping));
        }
        else 
        {
            wallJumpingCounter -= Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.UpArrow) && wallJumpingCounter > 0f)
        {
            isWallJumping = true;
            my_rb.velocity = new Vector2(wallJumpingDirection * wallJumpingPower.x, wallJumpingPower.y);
            wallJumpingCounter = 0f;

            if (transform.localScale.x != wallJumpingDirection)
            {
                isFacingRight = !isFacingRight;
                Vector3 localScale = transform.localScale;
                localScale.x *= -1f;
                transform.localScale = localScale;
            }

            Invoke(nameof(StopWallJumping), wallJumpingDuration);
        }
    }
    private void StopWallJumping()
    {
        isWallJumping = false;
    }
    private void Flip()
    {
        if (isFacingRight && isMoving < 0f || !isFacingRight && isMoving > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 localScale = transform.localScale;
            localScale.x *= -1f;
            transform.localScale = localScale;
        }
    }
}
