using UnityEngine;

public class WallSlide : MonoBehaviour
{
    private bool isWallSliding;
    public float wallSlidingSpeed;
    [SerializeField] private Transform wallCheck;
    [SerializeField] private LayerMask wallLayer;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private bool IsWalled()
    {
        return Physics2D.OverlapCircle(wallCheck.position, 0.2f, wallLayer);
    }


}
