using NUnit.Framework;
using System.Collections.Generic;
using UnityEngine;


public class spawncube : MonoBehaviour
{
    public GameObject myPrefab;
    public GameObject clone;

    public List<GameObject> cubeList = new List<GameObject>();

    //public int listLength = cubeList.Count;
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Mouse0)) {
            Vector2 spawnPosition = new Vector2(0f, 0f);
            clone = Instantiate(myPrefab, spawnPosition, Quaternion.identity); 
            Debug.Log("click");
            cubeList.Add(clone);
            Debug.Log(cubeList.Count);

        }
        if (Input.GetKeyDown(KeyCode.Mouse1)) {
            Destroy(clone);
            Debug.Log("rightClick");
            cubeList.Remove(clone);
            Debug.Log(cubeList.Count);
        }
    }
}
